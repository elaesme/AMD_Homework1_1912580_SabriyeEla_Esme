# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:02:19 2019

@author: Ela
"""

#EXCEPTIONS

#1)Exceptions
t=int(input())
for _ in range(t):
    try:                  #try to do the operations,if not possible, goes to except
     n,m=map(int,input().split())
     print(n//m)
    except ZeroDivisionError as e: #except error type 1
     print("Error Code:",e)
    except ValueError as f: #except error type 2
     print("Error Code:",f)
