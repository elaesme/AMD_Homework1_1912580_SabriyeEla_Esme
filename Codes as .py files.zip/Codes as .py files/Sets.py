# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 22:54:52 2019

@author: Ela
"""

#SETS

#1)Introduction To Sets

def average(array):
     array=set(array)
     resultt= ((sum(array))/(len(array)))
     return resultt

if __name__ == '__main__':
    n = int(input())
    arr = list(map(int, input().split()))
    result = average(arr)
    print(result)

#2)	No Idea!

n,m= map(int,input().split(' '))
array= list(map(int,input().split(' ')))
a= set(map(int, input().split(' ')))
b= set(map(int, input().split(' ')))

happy=0
sad=0

for i in array:
    if i in a:
     happy+=1
    elif i in b:
     sad+=1

result= (happy-sad)
print(result)      


#3)Set.add
n= int(input())
setofstamps= set()
for i in range(n):
    setofstamps.add(input())

print(len(setofstamps))



#4)Set.union()
n1, english= int(input()), set(input().split())
n2, french= int(input()), set(input().split())

total=(english.union(french))
print(len(total))

#5)Set.intersect()
n1, english= int(input()), set(input().split())
n2, french= int(input()), set(input().split())

intersect=english & french
print(len(intersect))


#6)Set.difference()
 n1, english= int(input()), set(input().split())
n2, french= int(input()), set(input().split())

diff= english - french
print(len(diff))


#7)Set.symmetric_difference()

n1, english= int(input()), set(input().split())
n2, french= int(input()), set(input().split())

sdiff= english.symmetric_difference(french)
print(len(sdiff))








#8)The Captains Room
k=int(input())
roomlist=list(map(int, input().split()))
roomset=set(roomlist)

captainsroom= (sum(roomset)*k-sum(roomlist))//(k-1)
print(captainsroom)



#9) Check Subset
t= int(input())
for i in range(t):
 n1, seta= int(input()), set(map(int, input().split(' ')))
 n2, setb= int(input()), set(map(int, input().split(' ')))

 if len(seta.difference(setb))== 0:
  print(True)
 else:
  print(False)



#10)Check Strict Superset
seta=set(input().split())
n=int(input())
c=0
for i in range(n):
 setn=set(input().split())
 if (setn.issubset(seta)==True) and (len(seta.difference(setn))>=0) :
      c+=1
 
if c==n :
    print(True)
else:
    print(False)








#-11) Symmetric Difference

m = int(input())
a = set(map(int, input().split()))
n = int(input())
b = set(map(int, input().split()))

diff= a.symmetric_difference(b)   #find the symmetric difference. Sorted(), sorts the set of elements in ascending order
sdiff= sorted(diff)
for i in range(len(diff)):
    print(sdiff[i])         #print every element of sorted diff in a different line






#12) Set discard(), remove(), pop()
n = int(input())
s = set(map(int, input().split()))
num= int(input())  
for _ in range(num):
  operation=input().split() #split the operation name and the number to be operated
  if operation[0]=="pop":    #check the first element of the input to find the operation,
    s.pop()                    #then operate the second element of the input of set s
  elif operation[0]=="remove":  #for pop(), we don't need to look for second element                                       because it removes an arbitrary element
    s.remove(int(operation[1]))
  elif operation[0]=="discard" :
    s.discard(int(operation[1]))

print(sum(s)) #print the elements of set s



#13)Set Mutations
numel = int(input())
a = set(map(int, input().split()))
num= int(input())  
for _ in range(num):
  operation=input().split()
  b=set(map(int, input().split()))
  if operation[0]=="intersection_update": 
    a.intersection_update(b)           
  elif operation[0]=="symmetric_difference_update": 
    a.symmetric_difference_update(b)
  elif operation[0]=="difference_update" :
    a.difference_update(b)
  elif operation[0]=="update" :
    a.update(b)

print(sum(a)) 

# Nearly same as the question: Set discard(), remove(), pop(), first get the inputs then for the given number of operations, get 2 different lines of inputs and the first line's first element contains the name of the operation. If the operation's name equal to one of the four different operations, then operate set a with the given operation with set b. then print the sum of set a.


