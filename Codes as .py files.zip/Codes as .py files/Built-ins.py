# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 22:59:19 2019

@author: Ela
"""

#BUILT-INS

#1)	Zipped!

grades=[]
n,x= map(int,input().split())
for i in range(x):
    grades.append(map(float, input().split())) #append grades to the list
        
zipped=zip(*grades) #zip the grades into one list
for i in zipped:
    summ=sum(i) #sum the grades for 1 student
    print(summ/x) #average

