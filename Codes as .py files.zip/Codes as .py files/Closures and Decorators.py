# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:03:09 2019

@author: Ela
"""

#CLOSURES AND DECORATORS

#1)Standardize Mobile Numbers Using Decorators
def wrapper(f):
    def fun(l):
          f(map(lambda x: "+91 " + x[-10:-5] + " " + x[-5:], l)) #formatting with lambda, '+91' + starting from the last digit get 5 digits + whitespace + the next 5 digits from right to left
    return fun

@wrapper

