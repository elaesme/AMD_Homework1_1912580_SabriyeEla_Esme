# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:12:16 2019

@author: Ela
"""

#REGEX

#1)Detect Floating number

import re
t=int(input())
for _ in range(t): #for t different lines 
  print(bool(re.search(r"^[+-.]?[0-9]*\.[0-9]+$", input()))) #search the string input with the constraints of: ^: Starting character,  [+-.]: The characters specified at the problem, ? after these characters: means that it can be either of them, [0-9]: means any number from 0-9, * after [0-9]: means that [0-9] can repeat artbitrarily  or it can't repeat at all, \. : means escape and a dot, [0-9] explained before, + after [0-9]: means that [0-9] can repeat artbitrarily  but different from *, it have to repeat at least 1 time, $: ending character. Boolean check to determine if its True or False(in other words detect a float number)

2)	Re.split()
regex_pattern = r"[.,]+"    #[.,]: are the characters specified in the question, + maens that either of the characters specified earlier
#the rest means to split the given string by the pattern I indicated and seperate them and print them on different lines 
import re
print("\n".join(re.split(regex_pattern, input())))




#3)Group(), groups() and groupdict()

import re
s= input()
m= re.search(r'([a-zA-Z0-9])\1',s) #[a-zA-Z0-9]: Any upper and lowercase letters + any numbers, \1: matches the characters repeats more than 1 time
if m:
    print(m.group(1)) #from m, get the first one
else:
    print(-1)








#4)Re.findall() and re.finditer()

import re
s= str(input())
m= re.findall(r'[QWRTYPSDFGHJKLZXCVBNMqwrtypsdfghjklzxcvbnm]([AEIOUaeiou]{2,})(?=[QWRTYPSDFGHJKLZXCVBNMqwrtypsdfghjklzxcvbnm])',s) #from left to right: one of the constanants, at least 2 vowels, '?=' positive look ahead for the next set of characters(consanants) 
if m:
    for i in m: 
        print(i)
else:
    print('-1')





#5)	Re.start() and re.end()

import re
s= input()
k=input()
pattern= r'(?='+k+')' #created the pattern to look for positive look ahead(?=) and given input k 
m=list(re.finditer(pattern, s)) #listed finditer of k in s

if m:
    for index in m:
         print((index.start(),(index.start()+len(k)-1))) #start() and end() works for re.search() but they do not work with finditer, because it only gives the start not end. That's why I used index.start()+len(k)-1 for the end index
else:
    print('(-1, -1)') #(-1,-1) did not work but (-1, -1) did.

    






#6)Regex Substitution

import re

n= int(input())
for _ in range(n):  
 s=str(input())
 s=re.sub(r'(\s\&\&)(?=\s)', ' and', s) #\s means whitespace. Substitute the && to and for the given input 
 s=re.sub(r'(\s\|\|)(?=\s)', ' or', s) #\s means whitespace. Substitute the || to or for the given input 
 print(s)

7)	Validating Roman Numerals

regex_pattern = r"(^M{0,3}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3}))$"   # I did not know the rules for formatting a valid roman number that's why I searched for the rules an found this website: https://www.math-only-math.com/rules-for-formation-of-roman-numerals.html but only 4 of the cases succeeded with the regex pattern I wrote with these rules. That's why I have searched about a solid regex pattern for validating roman numbers and I fount this website:https://regexr.com/3a406 with explanation I've only changed M{0,4} to 0,3 because in the problem there is a constraint about number<=3999. 

import re
print(str(bool(re.match(regex_pattern, input()))))




#8)	Validating Phone Numbers

import re
n=int(input())
for _ in range(n):
    a=re.match(r"[7|8|9]{1}\d{9}$", input()) #[7|8|9]{1}: means 7or8or9 exactly 1 times, \d{9}: means any digit exactly 9 times, $:end match
    if a:
        print('YES')
    else:
        print('NO')




#9)	Validating and Parsing email adresses

import re
n=int(input())
for _ in range(n):
    s,i= map(str,input().split())
    a=re.match(r'<[a-zA-Z]{1}[\.|a-zA-Z|\-|\_|\d]*[@]{1}[a-zA-Z]+[\.]{1}[a-zA-Z]{,3}>$', i) #[a-zA-Z]{1}: letter only one time for the start, [\.|a-zA-Z|\-|\_|\d]*: .,letters,-,_,numbers can repeat arbitrary times or none, [@]{1}: @ exactly 1 time,[a-zA-Z]*: letters can repeat arbitrary times but at least once, [\.]{1}: . exactly one time,[a-zA-Z]{,3}: letters max 3 times
    if a:
        print(s,i)




#10)	Hex Color Code

import re
n=int(input())
for _ in range(n):
    s=input()
    m= re.findall(r'[\s:](#[a-fA-F0-9]{3,6})',s) #[\s:]: either a space or a colon,#[a-fA-F0-9]{3,6} letters from a to f, for length between 3 to 6 (in the question it says that the length can be either 3 or 6 but this expression works for every input)
    if m:
     for i in m: 
        print(i)









#11)	HTML parser part 1

from html.parser import HTMLParser
class MyHTMLParser(HTMLParser): #from the problem with minor changes:
    def handle_starttag(self, tag, attrs):
        print("Start :", tag) 
        if(len(attrs)>=1):
                for i in range(len(attrs)):
                    print("->", attrs[i][0], ">", attrs[i][1]) #attrs[i][0] indicates the attribute, attrs[i][1]: indicates the attribute value, and the strings at the end and at the middle are from the task part of the question
    def handle_endtag(self, tag):
        print("End   :", tag)
    def handle_startendtag(self, tag, attrs):
        print("Empty :", tag)
        if(len(attrs)>=1):
                for i in range(len(attrs)):
                    print("->", attrs[i][0], ">", attrs[i][1]) #attrs[i][0] means the attribute, attrs[i][1]: means the attribute value, and the strings at the end and at the middle are from the task part of the question

parser = MyHTMLParser()
n=int(input())
for _ in range(n):
    s=input()
    parser.feed(s)



#12)	HTML Parser Part 2

from html.parser import HTMLParser

class MyHTMLParser(HTMLParser):
      def handle_comment(self, comment):
          if '\n' in comment: #if the comment has more than 1 line(seperated by '\n')
              print('>>> Multi-line Comment')  #print multi lines  
              print(comment)
          else:
              print('>>> Single-line Comment') #else print single line
              print(comment)
      def handle_data(self, data):
            if data!='\n':    #In the task part of the question, it says that: Do not print data if data == '\n', son in here we check that
             print('>>> Data')
             print(data)
         
html = ""       
for i in range(int(input())):
    html += input().rstrip()
    html += '\n'
    
parser = MyHTMLParser()
parser.feed(html)
parser.close()



#13)	Detect HTML Tags, Atts. and Att. Values
from html.parser import HTMLParser
class MyHTMLParser(HTMLParser): #everything here is nearly same with my HTML Parser Part 1 code because both of the questions ask for the same thing
    def handle_starttag(self, tag, attrs):
        print(tag) 
        if(len(attrs)>=1):
                for i in range(len(attrs)):
                    print("->", attrs[i][0], ">", attrs[i][1]) #attrs[i][0] indicates the attribute, attrs[i][1]: indicates the attribute value, and the strings at the end and at the middle are from the task part of the question
    
parser = MyHTMLParser()
n=int(input())
for _ in range(n):
    s=input()
    parser.feed(s)

 





#14)	Validatin UID

import re
t=int(input())
for _ in range(t):
    a=re.match(r'^(?!.*(.).*\1)(?=(?:[A-Z]*){2,})(?=(?:.*[0-9]){3,})[a-zA-Z0-9]{10}$',input()) #a negative lookahead for repeating characters, in other words, no repeating characters, (?=(?:[A-Z]*){2,}) positive lookahead, non-capturing(does not create a group) for A-Z characters at least length of 2, (?=(?:.*[0-9]){3,}):positive lookahead, non-capturing(does not create a group) for 0-9 characters at least length of 3, [a-zA-Z0-9]{10}: all the characters stated will be at exact length of 10.
    if a:
        print('Valid')
    else:
        print('Invalid')


