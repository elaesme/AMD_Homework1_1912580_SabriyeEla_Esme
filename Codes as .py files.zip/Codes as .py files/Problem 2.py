# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:14:49 2019

@author: Ela
"""

#PROBLEM 2

#1)Birthday Cake Candles

import math
import os
import random
import re
import sys


def birthdayCakeCandles(ar):
    c= max(ar) #find the max value of the array
    count=0
    for i in ar: #look every element of the array and if the element is equal to max                                increase count by 1
      if i==c:
         count+=1
    return count

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    ar_count = int(input())

    ar = list(map(int, input().rstrip().split()))

    result = birthdayCakeCandles(ar)

    fptr.write(str(result) + '\n')

    fptr.close()










#2)	Kangaroo

import math
import os
import random
import re
import sys
#we are looking for the condition, at some time i, (x1+i*v1)==(x2+i*v2), if we try to solve the problem, it gives us (x2-x1)==i*(v1-v2), next step, ((x2-x1)/(v1-v2))==i, since we are working with integers, i must be an integer time and that's why (x2-x1)%(v1-v2) == 0 equality should hold. And we have to keep in mind that, for this equality to hold v2 has to be smaller than v1. In other words: 

def kangaroo(x1, v1, x2, v2):
    if(v1>v2 and ((x2-x1)%(v1-v2)==0)):  
        ans="YES"
    else:
        ans="NO"
    return ans

if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    x1V1X2V2 = input().split()

    x1 = int(x1V1X2V2[0])

    v1 = int(x1V1X2V2[1])

    x2 = int(x1V1X2V2[2])

    v2 = int(x1V1X2V2[3])

    result = kangaroo(x1, v1, x2, v2)
    
    fptr.write(result +'\n')

    fptr.close()


