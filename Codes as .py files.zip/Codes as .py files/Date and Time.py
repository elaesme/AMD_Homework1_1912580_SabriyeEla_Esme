# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:04:19 2019

@author: Ela
"""
#DATE AND TIME

#1)	Calendar Module

import calendar
m,d,y= map(int,input().split())
day= calendar.weekday(y, m, d)   #from pythondocs I found this function which returns the days of week as an integer between 0-6 for given y-m-d parameters. link:https://docs.python.org/2/library/calendar.html#calendar.setfirstweekday
if day==0:
    print('MONDAY')
elif day==1:
    print('TUESDAY')
elif day==2:
    print('WEDNESDAY')
elif day==3:
    print('THURSDAY')
elif day==4:
    print('FRIDAY')
elif day==5:
    print('SATURDAY')
elif day==6:
    print('SUNDAY')



