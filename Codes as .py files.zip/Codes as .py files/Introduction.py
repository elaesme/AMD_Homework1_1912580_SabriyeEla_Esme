# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# INTRODUCTION

#Hello World
1)	print("Hello, World!")

#2)	Python If-Else


import math
import os
import random
import re
import sys


if __name__ == '__main__':
    n = int(input().strip())

if n % 2 == 1 :
  print("Weird")
elif n % 2 == 0 & 2<=n<=5 :
  print("Not Weird")
elif n % 2 == 0 & 6<=n<=20 :
  print("Weird")
elif n % 2 == 0 & 20<n :
  print("Not Weird")




#3)	Arithmetic Operators
if __name__ == '__main__':
    a = int(input())
    b = int(input())

print(a+b)
print(a-b)
print(a*b)



#4)Python division
if __name__ == '__main__':
    a = int(input())
    b = int(input())

print(a//b)
print(a/b)
 

#5)Loops
if __name__ == '__main__':
    n = int(input())

for x in range(0,n):
 print(x*x)


#6)Write a function
def is_leap(year):
    leap = False
    if (year % 4) == 0 :
        if (year % 100) == 0 :
          if (year % 400) == 0:

              return True
          else :
             return leap
        else : 
         return True
    else :        
      return leap

year = int(input())


#7)Print Function
from __future__ import print_function 
if __name__ == '__main__':
    n = int(input())

mylist=list(range(1, n+1)) 
print(*mylist, sep='')








  

