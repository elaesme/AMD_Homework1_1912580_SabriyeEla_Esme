# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 22:49:54 2019

@author: Ela
"""

#DATA TYPES


#1)	List Comprehensions
if __name__ == '__main__':
    x = int(input())
    y = int(input())
    z = int(input())
    n = int(input())

print([[i,j,k] for i in range(0,x+1) for j in range(0,y+1) for k in range(0,z+1) if i+j+k!=n])


#2) Find the Runner up Score
if __name__ == '__main__':
    n = int(input())
    arr = set(map(int, input().split())) #made arr a set so no element can repeat.
    x= max(arr)  #then find the max element of arr
    arr.remove(x) #removed it from arr
    print(max(arr)) #then printed the maximum, which will be the second max of the original list




#3)	Finding the Percentage
if __name__ == '__main__':
    n = int(input())
    student_marks = {}
    for _ in range(n):
        name, *line = input().split()
        scores = list(map(float, line))
        student_marks[name] = scores
        wanted_name = input()

    print("%.2f" % ((sum(student_marks[wanted_name]))/3))





#4)Nested Lists

if __name__ == '__main__':
    lst=[]
    scores=[]
    for _ in range(int(input())):
        name = input()
        score = float(input())
        lst.append([name,score]) #nested list 
        scores.append(score) #score list
    
    sscores=sorted(list(set((scores)))) #first set the list so there won't be repeating elements, than make it a list again and sorted func sort the scores in ascending order
    scndlwst= sscores[1] #second lowest score is the second element of sorted scores list

    slst=sorted(lst)  #sorts nested list in alphabethical order

    for x,y in slst:   #for every duo in the list
        if y==scndlwst: #if the score is equal to 2nd lowest, print the name 
         print(x)
    
  
  


#5)Lists

if __name__ == '__main__':
 N = int(input())
 lst = []  
 for _ in range(N):
   operation=input().split() #split the operation name and the number to be operated
   if operation[0]=="pop":   #check the first element of the input to find the operation
     lst.pop()                    
   elif operation[0]=="remove":  
     lst.remove(int(operation[1]))
   elif operation[0]=="append" :
     lst.append(int(operation[1]))
   elif operation[0]=="insert" :
     lst.insert(int(operation[1]), int(operation[2]))
   elif operation[0]=="reverse" :
     lst.reverse()
   elif operation[0]=="sort":
       lst.sort()
   elif operation[0]=="print":
       print(lst)

#If the operation's name equal to one of the 7 different operations, then operate lst with the given operation and value. 



#6)Tuples
if __name__ == '__main__':
    n = int(input())
    integer_list = map(int, input().split())

t = tuple(integer_list)
print(hash(t))

