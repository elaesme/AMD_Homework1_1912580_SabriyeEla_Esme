# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:10:55 2019

@author: Ela
"""

#XML 




#1)Find the Score

import sys
import xml.etree.ElementTree as etree

def get_attr_number(node):
    a=() #created an empty tuple
    for elem in node.iter():     #iterate every element in node(root)
       a+=((tuple(elem.attrib))) #add every elements attribute as a tuple to empty tuple
    return(len(a)) #return the length of tuple to the score(number of atributes)
if __name__ == '__main__':
    sys.stdin.readline()
    xml = sys.stdin.read()
    tree = etree.ElementTree(etree.fromstring(xml))
    root = tree.getroot()
    print(get_attr_number(root))



#2)Find the Maximum Depth

import xml.etree.ElementTree as etree

maxdepth = 0
def depth(elem, level):
    global maxdepth
    level += 1
    if level >= maxdepth:   #if level is bigger than maxdepth update maxdepth as level
        maxdepth = level
    for child in elem:        #each xml element has a number of child elements, stored                                  in a Python sequence, explanation in here https://docs.python.org/2/library/xml.etree.elementtree.html 
           depth(child, level)    #for every child we should call depth, 
    return (maxdepth)

if __name__ == '__main__':
    n = int(input())
    xml = ""
    for i in range(n):
        xml =  xml + input() + "\n"
    tree = etree.ElementTree(etree.fromstring(xml))
    depth(tree.getroot(), -1)
    print(maxdepth)

