# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:09:36 2019

@author: Ela
"""

#PYTHON FUNCTIONALS
cube = lambda x: pow(x,3)

def fibonacci(n):
    l=[]
    for i in range(n):
        if i<2: 
         l.append(i)    #for the first 2 elements their fibonacci numbers are themselves
        else:
         l.append(l[i-2] + l[i-1])
    return l              #Fibonacci number is the sum of the two preceding numbers, that's why I indicated the return of first 2 positive integers  and created a recursive function to compute next ones.

if __name__ == '__main__':
    n = int(input())
    print(list(map(cube, fibonacci(n))))
