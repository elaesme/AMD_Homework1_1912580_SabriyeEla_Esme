# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:05:49 2019

@author: Ela
"""
#NUMPY

#1)Shape and reshape
 
 import numpy

arrayy= numpy.array(input().split(), int)

print(numpy.reshape(arrayy,(3,3)))


#2)Transpose and Flatten

import numpy
n,m= map(int,input().split())
arrayy=[]
for _ in range(n):
    arrayy.append(numpy.array(input().split(), int)) #ad every line to array
arrayy1= numpy.reshape(arrayy,(n,m)) #make the array a nxm matrix
print(numpy.transpose(arrayy1)) #transpose 
print(arrayy1.flatten()) #flatten



#3)Concacenate

import numpy

n,m,p= map(int,input().split())
arr1=[]
arr2=[]
for _ in range(n):
     arr1.append(numpy.array(input().split(), int))  
for _ in range(m):
     arr2.append(numpy.array(input().split(), int)) 

print(numpy.concatenate((arr1, arr2), axis = 0))






#4)Arrays

import numpy

def arrays(arr):
    new= numpy.array(arr[::-1],float) #reverse the array and make the elements type float
    return new

arr = input().strip().split(' ')
result = arrays(arr)
print(result)




#5)Zeros and ones

import numpy
n = list(map(int,input().split()))
print(numpy.zeros((n), dtype= numpy.int)) #creating zeros matrix
print(numpy.ones((n), dtype= numpy.int))  #creating ones matrix
    




#6)Sum and Product

import numpy
n,m = map(int, input().split())
arr=[]
for _ in range(n):
 arr.append(numpy.array(input().split(), int))  #append n lines to an empty array
arr1=numpy.sum(arr, axis = 0)  #getting the sum array
print(numpy.prod(arr1))  




#7)Polynomials
import numpy
n = list(map(float,input().split()))
x= int(input())
print(numpy.polyval(n, x)) #polyval evalueates the result of a polynomial with coefficients n at given point x




#8)Inner and Outer

import numpy
a= numpy.array(input().split(), int)
b= numpy.array(input().split(), int)
print(numpy.inner(a,b))
print(numpy.outer(a,b))




#9)Min and Max

import numpy
arr=[]
n,m = map(int, input().split())
for _ in range(n):
    arr.append(numpy.array(input().split(), int)) #appending n lines to an empty array

minn= numpy.min(arr, axis = 1)  #finding min
print(numpy.max(minn))     #finding max of th min array



#10)Dot and Cross

import numpy
n= int(input())
a=[]
b=[]
for _ in range(n):
 a.append(numpy.array(input().split(), int)) #inputs to append to the array a
for _ in range(n): 
 b.append(numpy.array(input().split(), int)) #inputs to append to the array b
print(numpy.dot(a,b)) #matrix multiplication





#11)Sum and Prod

import numpy
n,m = map(int, input().split())
arr=[]
for _ in range(n):
 arr.append(numpy.array(input().split(), int))  #append n lines to an empty array

sum= numpy.sum(arr, axis = 0)  #find the sum of newly created array arr
print(numpy.prod(sum)) #print the product of the sum array




#12)	Array Mathematics

import numpy
a,b= map(int,input().split())
arr1=numpy.array([input().split() for _ in range(a)], int)  #creating array with n lines
arr2=numpy.array([input().split() for _ in range(a)], int) #creating array with n lines

print(numpy.add(arr1,arr2)) #operations
print(numpy.subtract(arr1,arr2))
print(numpy.multiply(arr1,arr2))
print(arr1//arr2)
print(numpy.mod(arr1,arr2))
print(numpy.power(arr1,arr2))










#13)Floor ceil and rint

import numpy
numpy.set_printoptions(sign=' ') #even though all my answers were correct, it keeps giving an error because the space between the required answers were different than mine. So, I searched online and found out about the print option of numpy.Here's the link: https://docs.scipy.org/doc/numpy-1.14.1/reference/generated/numpy.set_printoptions.html  -If ' ', always prints a space (whitespace character) in the sign position of positive values.-
arr=numpy.array(input().split(), float)  
print(numpy.floor(arr))
print(numpy.ceil(arr))
print(numpy.rint(arr))



#14)Mean Var and Std
import numpy
numpy.set_printoptions(sign=' ') #even though all my answers were correct, it keeps giving an error because the space between the required answers were different than mine. So, I searched online and found out about the print option of numpy.Here's the link: https://docs.scipy.org/doc/numpy-1.14.1/reference/generated/numpy.set_printoptions.html  -If ' ', always prints a space (whitespace character) in the sign position of positive values.-
n,m= map(int,input().split())
arr=numpy.array([input().split() for _ in range(n)], int)  
print(numpy.mean(arr,axis=1))
print(numpy.var(arr,axis=0))
print(numpy.around( numpy.std(arr), 12)) #needed to reduce the decimal places because even though the answer is true, required solution needs to be reduced






#15)Linear Algebra

import numpy
n= int(input())
arr=numpy.array([input().split() for _ in range(n)], float)
print(numpy.around(numpy.linalg.det(arr),2)) #again, even though it is not specified in the question, the required answer must be in 2 decimal places because otherwise one of the cases fails. 




#16)Eye and identity

import numpy
numpy.set_printoptions(sign=' ') #even though all my answers were correct, it keeps giving an error because the space between the required answers were different than mine. So, I searched online and found out about the print option of numpy.Here's the link: https://docs.scipy.org/doc/numpy-1.14.1/reference/generated/numpy.set_printoptions.html  -If ' ', always prints a space (whitespace character) in the sign position of positive values.-
n,m= map(int,input().split())
print(numpy.eye(n, m, k = 0)) 


