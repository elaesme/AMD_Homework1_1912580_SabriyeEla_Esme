# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 23:00:45 2019

@author: Ela
"""

#COLLECTIONS

#1)collections.Counter()
from collections import Counter
x= int(input())
c= Counter(map(int, input().split()))
n= int(input())
revenue= []
for _ in range(n): 
  size, price=map(int, input().split())
  if c[size]>0 :  #if Raghu has the required shoe size (from the counter, if the size has a count more than 0)
      revenue.append(price)
      c[size]-=1  #it will be sold, so we should decrease the count of the size by 1

  
summ=(sum(revenue)) #to get the total revenue we should sum the elemnts of the revenue list(prices of the sold shoes)
print(summ)





#2) Collections.namedtuple()
from collections import namedtuple
n= int(input())
stuinfo= input().split()
info= namedtuple('info', stuinfo) #creating a namedtuple consist of marks id name class of the students(random order)
mark=[]
for i in range(n):
    a,b,c,d=  input().split() #getting inputs 
    info2= info(a,b,c,d) #creating the tuple for every student
    mark.append(int(info2.MARKS))#adding every mark of the student to a list with calling MARKS from the tuples


print("%.2f"%((sum(mark))/n))  #Average of the marks with 2 decimal places





#3) Collections.ordereddict()
from collections import OrderedDict
n= int(input())
order=OrderedDict()
for _ in range(n):
    name,price=input().rsplit(' ',1) #split the input from rigt to left with whitespace, maxsplit=1 so it will return 2 items, name and price
    if name not in order:     #if name not in the ordereddict than the name's price is the price given at the input
        order[name]=int(price)
    else:                        #if the name was already on the ordereddict than the name's price will be added with the previous given price
        order[name]=order[name]+int(price)

for i in order.items():
    print(*i) #print the unpacked arguements out of ordereddict

