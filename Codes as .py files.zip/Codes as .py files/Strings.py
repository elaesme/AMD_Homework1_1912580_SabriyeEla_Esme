# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 22:51:25 2019

@author: Ela
"""

#STRINGS


#1)Swap Case
def swap_case(s):
    final=''
    for x in s:
        if x.isupper()==True:
          final+=x.lower()
        elif x.islower()==True:
          final+=x.upper()
        else:
          final+=x  
    return final

if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)

#2) String Split and join
def split_and_join(line):
    line=line.split(" ")
    line="-".join(line)
    return line

if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)



#3) What’s your name?
def print_full_name(a, b):
    print("Hello {firstname} {lastname}! You just delved into python.".format(firstname=a, lastname=b))

if __name__ == '__main__':
    first_name = input()
    last_name = input()
    print_full_name(first_name, last_name)





#4) Mutations
def mutate_string(string, position, character):
    listt=list(string)
    listt[position]= character
    string=''.join(listt)
    return string

if __name__ == '__main__':
    s = input()
    i, c = input().split()
    s_new = mutate_string(s, int(i), c)
    print(s_new)

#5) String Validators
if __name__ == '__main__':
    s = input()

c1=0
c2=0
c3=0
c4=0
c5=0
for a in s:
 if a.isalnum():
     c1+=1
if c1>0 :
 print(True)
else:
 print(False)    
for a in s:
 if a.isalpha():
     c2+=1   
if c2>0 :
 print(True)
else:
 print(False) 
for a in s:
 if a.isdigit():
     c3+=1   
if c3>0 :
 print(True)
else:
 print(False)   
for a in s:
 if a.islower():
     c4+=1   
if c4>0 :
 print(True)
else:
 print(False)   
for a in s:
 if a.isupper():
     c5+=1   
if c5>0 :
 print(True)
else:
 print(False)      
                     
#6)Text Alignment

thickness = int(input()) #This must be an odd number
c = 'H'

#Top Cone
for i in range(thickness):
    print((c*i).rjust(thickness-1)+c+(c*i).ljust(thickness-1))

#Top Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))

#Middle Belt
for i in range((thickness+1)//2):
    print((c*thickness*5).center(thickness*6))    

#Bottom Pillars
for i in range(thickness+1):
    print((c*thickness).center(thickness*2)+(c*thickness).center(thickness*6))    

#Bottom Cone
for i in range(thickness):
    print(((c*(thickness-i-1)).rjust(thickness)+c+(c*(thickness-i-1)).ljust(thickness)).rjust(thickness*6))




#6) Find a String
def count_substring(string, sub_string):
    c=0
    length1=len(string) 
    length2=len(sub_string)
    for a in range(length1):
        if string[a: a+length2]==sub_string:
            c+=1
    
    return c

if __name__ == '__main__':
    string = input().strip()
    sub_string = input().strip()
    
    count = count_substring(string, sub_string)
    print(count)




#7) Text Wrap
import textwrap

def wrap(string, max_width):
    textwrap.wrap(string,max_width)
    final= textwrap.fill(string, max_width)
    return final

if __name__ == '__main__':
    string, max_width = input(), int(input())
    result = wrap(string, max_width)
    print(result)
    
    
    
#8) String Formatting
def print_formatted(number):
    for i in range(1,number+1): #formatted the number in range(1,n+1) from left to right d,o,x,b space padded to match the width of binary value of number
     print("{0:{width}d} {0:{width}o} {0:{width}X} {0:{width}b}".format(i, width=len("{0:b}".format(number))))
if __name__ == '__main__':
    n = int(input())
    print_formatted(n)



#9)Capitalize!

import math
import os
import random
import re
import sys

def solve(s):
    ss= s.split(' ')
    rslt= [i.capitalize() for i in ss] #capitalize returns the word with the first letter.upper(), so i did it for the every element of the input splited with whitespace
    return(' '.join(rslt)) # join function returns the elements of rslt list concatenated with whitespace between them
    
if __name__ == '__main__':
    fptr = open(os.environ['OUTPUT_PATH'], 'w')

    s = input()

    result = solve(s)

    fptr.write(result + '\n')

    fptr.close()


#10) Designer Door Mat

if __name__ == '__main__':
    n,m  = map(int, input2().split())  
    for i in range(1,n,2):             #Top part of the door mat with i number of .|.                                               #characters centered with - at sides
      print((i * ".|.").center(m, "-"))
    
    print("WELCOME".center(m,"-"))      #WELCOME at the center
    
    for i in range(n-2,-1,-2):            #Top part of the door mat with i number of .|.                                               #characters centered with - at sides
      print((i * ".|.").center(m, "-"))

